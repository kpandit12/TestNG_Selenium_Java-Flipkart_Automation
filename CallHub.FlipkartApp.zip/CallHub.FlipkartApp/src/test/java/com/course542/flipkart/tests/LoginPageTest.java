package com.course542.flipkart.tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.course542.flipkart.base.Driver;
import com.course542.flipkart.pages.Homepage;
import com.course542.flipkart.pages.LoginPage;

@Listeners(com.course542.flipkart.listeners.Listener.class)
public class LoginPageTest extends Driver {
	LoginPage loginPage;
	Homepage homepage;
	public static Logger log=LogManager.getLogger(LoginPageTest.class.getName());

	public LoginPageTest(){
		super();
	}

	@BeforeMethod
	public void setUp(){
		log.info("=======Launching Application========");
		log.info("Initializing Drivers");
		initialize();
		log.info("Driver loaded ... Traversing to Login Page");
		loginPage = new LoginPage();
	}

	@Test(enabled=false, priority=1)
	public void loginPopUpVerify() throws Exception{
		log.info("=======Login Page Test========");
		loginPage.logInPageVerifyElements();

	}
	
	@Test(enabled=false, priority=2)
	public void createNewAccountPageVerify() throws Exception{
		log.info("=======Login Page Test========");
		loginPage.verifyCreateNewAccountPage();
	}

	@Test(enabled=true, priority=3)
	public void LoginPageVerifyLogin() {
		log.info("Sending username and password to login page!");
		try {
			homepage=loginPage.LoginToHome(prop.getProperty("email"), prop.getProperty("pass"));
			if(homepage!=null) {
				log.info("Successfully Logged in!");
				loginPage.logout();
				}
			}
		catch(Exception e) {
			log.error("Login failed!");
			AssertJUnit.fail("Homepage=null");
		}
	}

	@AfterMethod
	public void tearDown(){
		log.info("Closing browser");
		driver.close();
		log.info("Browser closed");
	}
}
