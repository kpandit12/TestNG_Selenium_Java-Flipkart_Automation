package com.course542.flipkart.tests;

import static org.testng.AssertJUnit.assertEquals;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.course542.flipkart.base.Driver;
import com.course542.flipkart.pages.Homepage;
import com.course542.flipkart.pages.LoginPage;
import com.course542.flipkart.pages.SearchPage;

public class HomepageTest extends Driver {
	LoginPage login;
	Homepage homepage;
	SearchPage searchpage;
	public static Logger log=LogManager.getLogger(HomepageTest.class.getName());

	public HomepageTest() {
		super();
	}

	@BeforeTest
	public void setUp() throws Exception {
		log.info("======Starting HomePage Test!=========");
		log.info("Initializing Drivers");
		initialize();
		log.info("Driver loaded! Traversing to LoginPage!");
		login=new LoginPage();
		log.info("login page initialized");
		try{
			homepage=login.LoginToHome(prop.getProperty("email"), prop.getProperty("pass"));
			if(homepage!=null) {
				log.info("Successfully Logged in! Loading to homepage.");
				}
			}catch(Exception e) {
				log.error("Login failed!");
			}
	}

	@Test(priority=1)
	public void verifyHomePageTitileTest() {
		homepage = new Homepage();
		log.info("verifying HomePageTitle");
		String title = homepage.getTitle();
		System.out.println("*********************************************");
		System.out.println("Title:"+title);
		log.info("Found homePageTitle->"+title);
		Assert.assertEquals(title,prop.getProperty("homePageTitle"));
		log.info("Title Verified!");
	}

	@Test(priority=2)
	public void verifyHomepageCorrectSignIn() {
		homepage = new Homepage();
		log.info("Verifying username");
		homepage.validateCorrectProfile();
	}

	@Test(priority=3)
	public void searchProductFromHomepage() throws Exception {
		homepage = new Homepage();
		log.info("typing product name in search bar.....");
		Thread.sleep(3000);
		homepage = homepage.Search(prop.getProperty("toSearch"));
		if(homepage!=null) {
			log.info("Successfully Searched the product!");

		}else {
			throw new Exception("Coudn't search product!");
		}
		login.logout();
	}
	

	@AfterMethod
	public void teardown() {
		log.info("Closing browser...");
		driver.close();
		log.info("Browser closed!");
	}
}
