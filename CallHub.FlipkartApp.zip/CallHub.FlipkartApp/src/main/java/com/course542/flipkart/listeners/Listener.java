package com.course542.flipkart.listeners;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;


public class Listener  implements ITestListener {
	public static Logger log=LogManager.getLogger(Listener.class.getName());
	@Override
	public void onTestStart(ITestResult result) {
		System.out.println(result.getMethod().getMethodName()+" Started! ");
		log.info(result.getMethod().getMethodName()+" Started! ");
		System.out.println("=============================================================================");

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println(result.getMethod().getMethodName()+" test Success! ");
		log.info(result.getMethod().getMethodName()+" test successfull! ");
		System.out.println("=============================================================================");

	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println(result.getMethod().getMethodName()+" test failed! ");
		log.info(result.getMethod().getMethodName()+" test failed! ");
		System.out.println("=============================================================================");

	}

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println(result.getMethod().getMethodName()+" test Skipped! ");
		log.info(result.getMethod().getMethodName()+"test skipped! ");
		log.info("Retrying...........");
		System.out.println("=============================================================================");

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	@Override
	public void onStart(ITestContext context) {


	}

	@Override
	public void onFinish(ITestContext context) {


	}

}
