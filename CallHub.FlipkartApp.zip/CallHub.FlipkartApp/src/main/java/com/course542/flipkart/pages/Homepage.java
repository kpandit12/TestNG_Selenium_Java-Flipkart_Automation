package com.course542.flipkart.pages;


import static org.testng.AssertJUnit.assertTrue;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.course542.flipkart.base.Driver;
import com.course542.flipkart.util.TestUtil;


public class Homepage extends Driver{

	public static Logger log=LogManager.getLogger(Homepage.class.getName());

	@FindBy(xpath="//div[@class='_1jA3uo'][1]/child::div[1]/child::div[1]/child::span[1]/child::div[@class='_2aUbKa'][1]")
	WebElement signerName;

	@FindBy(xpath="//*[@title='Search for products, brands and more']")
	WebElement searchBox;

	@FindBy(xpath="//*[@title='Search for products, brands and more']/../../button[@type='submit']")
	WebElement searchButton;
	
	@FindBy(xpath="//*[text()='Ketaki']")
	WebElement username;
	
	@FindBy(xpath="//div[contains(text(),'APPLE iPhone 12 (Blue, 128 GB')]")
	WebElement searchedProduct;

	public Homepage(){
		PageFactory.initElements(driver, this);
	}


	public String getTitle() {
		log.info("Title found! Returning to HomePageTest");
		return driver.getTitle();
	}

	public Homepage validateCorrectProfile() {
		Assert.assertTrue(TestUtil.isDisplayed(username));
		return new Homepage();
	}

	public Homepage Search(String product) throws InterruptedException  {
		log.info("Product to search->"+product+". Typing "+product+" in search box.");
		searchBox.sendKeys(product);
		log.info("ImplicitWaiting");
		log.info("Pressing Enter Key");
		searchBox.sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		Assert.assertTrue(TestUtil.isDisplayed(searchedProduct));
		return new Homepage();
	}
}
