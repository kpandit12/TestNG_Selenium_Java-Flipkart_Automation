package com.course542.flipkart.pages;

import static org.testng.AssertJUnit.assertTrue;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.course542.flipkart.base.Driver;
import com.course542.flipkart.util.TestUtil;

public class LoginPage extends Driver {
	public static Logger log=LogManager.getLogger(LoginPage.class.getName());

	@FindBy(xpath="//span[text()='Login']/../../p/span[text()='Get access to your Orders, Wishlist and Recommendations']")
	WebElement loginPageTexts;
	
	@FindBy(xpath="//button[text()='✕']")
	WebElement xButton;

	@FindBy(xpath="//*[contains(text(),'CONTINUE')]")
	WebElement continueButton;
	
	@FindBy(xpath="//*[contains(text(),'Existing User? Log in')]")
	WebElement existingUser;
	
	@FindBy(xpath="//*[contains(text(),'Enter Mobile number')]")
	WebElement enterMobileNumber;

	@FindBy(xpath="//button[contains(text(),'Login with Password')]")
	WebElement loginwithpass;

	@FindBy(xpath="//span[text()='Enter Email/Mobile number']/../../input")
	WebElement email;

	@FindBy(xpath="//span[text()='Enter Password']/../../input")
	WebElement password;

	@FindBy(xpath="//*[text()='Login']/../../button[@type='submit']")
	WebElement loginButton;

	@FindBy(xpath="//*[text()='Request OTP']")
	WebElement reqOTP;
	
	@FindBy(xpath="//*[text()='New to Flipkart? Create an account']")
	WebElement createNewAccount;
	
	@FindBy(xpath="//*[text()='Forgot?']")
	WebElement forgotPassword;
	
	@FindBy(xpath="//*[text()='Terms of Use']")
	WebElement termsOfuse;
	
	@FindBy(xpath="//*[text()='Ketaki']")
	WebElement username;
	
	@FindBy(xpath="//*[text()='Logout']")
	WebElement logout;
	
	@FindBy(xpath="//*[text()='Login']")
	WebElement login;
	
	public LoginPage() {
		log.info("initializing driver");
		PageFactory.initElements(driver, this);
	}

	public LoginPage logInPageVerifyElements() throws Exception {
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		assertTrue(TestUtil.isDisplayed(loginPageTexts));
		assertTrue(TestUtil.isDisplayed(email));
		assertTrue(TestUtil.isDisplayed(password));
		assertTrue(TestUtil.isDisplayed(createNewAccount));
		assertTrue(TestUtil.isDisplayed(forgotPassword));
		assertTrue(TestUtil.isDisplayed(termsOfuse));
		assertTrue(TestUtil.isDisplayed(xButton));
		return new LoginPage();

	}
	
	public LoginPage verifyCreateNewAccountPage() throws Exception {
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		createNewAccount.click();
		Thread.sleep(500);
		assertTrue(TestUtil.isDisplayed(enterMobileNumber));
		assertTrue(TestUtil.isDisplayed(existingUser));
		assertTrue(TestUtil.isDisplayed(continueButton));
		assertTrue(TestUtil.isDisplayed(termsOfuse));
		// assertTrue(TestUtil.isDisplayed(xButton));
		existingUser.click();
		Thread.sleep(3000);
		assertTrue(TestUtil.isDisplayed(loginPageTexts));
		return new LoginPage();

	}

	public Homepage LoginToHome(String username,String pass) throws Exception {
		log.info("Entering email id as username");
		email.sendKeys(username);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		password.sendKeys(pass);
		log.info("Username and Password inserted");
		//Click on login
		loginButton.click();
		Thread.sleep(500);
		log.info("Login button clicked.");
		return new Homepage();
	}

	
	public LoginPage logout() throws Exception {
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		Thread.sleep(3000);
		assertTrue(TestUtil.isDisplayed(username));
		Actions action = new Actions(driver);
		action.moveToElement(username).perform();
		Thread.sleep(3000);
		assertTrue(TestUtil.isDisplayed(logout));
		logout.click();
		Thread.sleep(3000);
		assertTrue(TestUtil.isDisplayed(login));
		return new LoginPage();

	}
	


}
